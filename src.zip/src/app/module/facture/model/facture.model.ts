export class Facture {
    idFacture !: number;
    montantRemise !: number;
	montantFacture !: number;
     dateFacture !: Date ;
    }