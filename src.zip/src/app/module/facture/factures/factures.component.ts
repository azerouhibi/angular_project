import { AfterViewInit, Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Facture } from '../model/facture.model';
import { FactureService } from '../services/facture.service';
import { UpdateFactureComponent } from '../update-facture/update-facture.component';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from "@angular/material/dialog";
import { HeaderComponent } from 'src/app/pages/header/header.component';
import { getGeneratedNameForNode } from 'typescript';
import { MatInputModule } from '@angular/material/input';



@Component({
  selector: 'app-factures',
  templateUrl: './factures.component.html',
  styleUrls: ['./factures.component.css']
})
export class FacturesComponent implements OnInit {
  // @ViewChild(UpdateFactureComponent) c!: UpdateFactureComponent;
  factures!: Facture[]; //un tableau de chînes de caractères
  cat?: any;
  p = 1;
  j=-1;
  show=false;
  value = 'Clear me';
  // facturesFiltrèes?: Facture[];
  public current_factures?: Facture[];
  ListFacture!: Facture[];
  inputFacture!: Facture;
  showFormTemplate!: boolean;
  buttonValue!: string;
  div1: boolean = false
  
  @Output() deleteNotifEvent = new EventEmitter<Facture>();
  test!: Facture;
  i!: number;
  currentFacture = new Facture();
  searchValue!: string;
  gg?: HeaderComponent;

  constructor(private factureService: FactureService, private router: Router, private activatedRoute: ActivatedRoute, private modalService: NgbModal, private dialog: MatDialog) {
    
  }
  

  div1Function() {
    this.div1 = !this.div1
    this.show = !this.show

  }
  showForm() {
    if (this.showFormTemplate === false) {
      this.showFormTemplate = true
      this.buttonValue = "go Back to the List";
      this.inputFacture = new Facture();
    }
    else {
      this.buttonValue = "add new Product";
      this.showFormTemplate = false
    }
  }
  deleteFacture(p: Facture) {
    let conf = confirm("Etes-vous sûr ?");
    if (conf)
      this.factureService.deleteFacture(p.idFacture).subscribe(() => {
        console.log("facture supprimé");
      });
      this.reloadPage()
    // this.router.navigate(['factures']).then(() => {
    //   window.location.reload();
    // });
  }
  
  // search() {
  //   this.facturesFiltrèes = this.factures!.filter(res => 
  //     !this.cat || res.idFacture.toLocaleString().match(this.cat!.toLocaleString()));
  // }
  facturesFiltres?: Facture[]
  search() {
    this.i = this.cat.length;
    if (this.cat != "") {

      this.factures = this.factures?.filter(res => {
        return res.idFacture.toString().match(this.cat.toString())

      });
    } else if (this.cat == "") {
      this.ngOnInit();
    }
  }
  ggf(e: any) {
    this.factureService.listeFacture().subscribe(prods => {
      console.log(prods);
      this.factures = prods;
    });
  }

  ngOnInit(): void {
    this.showFormTemplate = false;
    this.buttonValue = "add new Facture";
    this.factureService.listeFacture().subscribe(prods => {
      console.log(prods);
      this.factures = prods;
    });

  }
  reloadPage() { let currentUrl = this.router.url; this.router.routeReuseStrategy.shouldReuseRoute = () => false; this.router.onSameUrlNavigation = 'reload'; this.router.navigate([currentUrl]); }

  save(facture: Facture = new Facture()): void {
    this.showFormTemplate = false;
    this.factureService.listeFacture().subscribe(prods => {
      console.log(prods);
      this.factures = prods;
      this.reloadPage()
    });
    // this.factureService.ajouterFacture(facture).subscribe((next) => { this.reloadPage() });
    // ()=>this.factures.push(facture)

  }


  delete(facture: Facture): void {
    let i = this.ListFacture.indexOf(facture);
    this.factureService.deleteFacture(facture.idFacture).subscribe(
      () => this.ListFacture.splice(i, 1)
    )
  }

  // update(facture: Facture): void {
  //   //in order to update a product, the parent component will change the input value
  //   //and send it to the child component

  //   this.inputFacture = facture;
  //   this.showFormTemplate = true;

  // }
  addRequest(t: Facture) {
    console.log(t);
    console.log("++++++++++++++++++++++");
  }
  // updateFacture() {
  //   this.router.navigate(['updateFacture']);


  // }

  onCreate() {

    this.dialog.open(UpdateFactureComponent, {
      height: '400px',
      width: '600px',
    });

  }
  // deleteNotif(){
  //   this.deleteNotifEvent.emit(this.factures)
  // }

  closeResult = '';

  open(content: any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }

  }


}


