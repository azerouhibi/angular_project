
export class Fournisseur{
    //id!:number;
    idFournisseur!:number;
    codeFournisseur !:string;
    libelleFournisseur !:string;
    email!: string;
    telephone!:number;
    adresse!:string;
    image!:string;

    active !:string;
    

    }
    